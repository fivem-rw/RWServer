### Master branch is now considered development work. Use the releases tab for stable builds.
https://discord.gg/GUvNXNe

**Default Controls**
https://github.com/MrDaGree/ELS-FiveM/wiki/Controls

**Installation Guide**
https://youtu.be/5-NGCLjew64
