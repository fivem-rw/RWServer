vcf_files = {
	"POLICE2.xml",
	"FBI.xml",
	"policet.xml",
	"sheriff2.xml",
	"polsonata.xml",
	"pford.xml",
	"Emst2.xml",
	"police6.xml",
	"sonata.xml",
	"db11ems.xml",
	"ambulance.xml",
	"db11scpd.xml",
}